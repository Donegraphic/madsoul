<?php
/**
 * Plugin Name: Recette Post
 * Description: Add Recette post in admin
 * Author:      Done Graphic
 * License URI: http://done-graphic.com
 * Version: 1.0
 */


function custom_recette_post()
{

	  
 $labels = array(
      'name' => 'Recettes',
      'singular_name' => 'Recette',
      'all_items' => 'Tous les Recettes',
      'add_new_item' => 'Ajouter une Recette',
      'edit_item' => 'Éditer la Recette',
      'new_item' => 'Nouvelle Recette',
      'view_item' => 'Voir la Recette',
      'search_items' => 'Rechercher parmi les Recettes',
      'not_found' => 'Pas de Recette trouvé',
      'not_found_in_trash'=> 'Pas de Recettes dans la corbeille'
      );
      
$args = array(
			'label'               => __( 'Recettes', 'Recettes' ),
			'description'         => __( 'Recettes', 'Recettes' ),
			'labels'              => $labels,
			'supports'            => array('title','editor','thumbnail','excerpt','revisions'),
			'taxonomies'          => array( 'category','post_tag' ),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'menu_icon'           => 'dashicons-carrot',
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
		);
		
register_post_type( 'recettes', $args );
	}

	/* Création du Custom Post */
add_action( 'init', 'custom_recette_post', 0 );

